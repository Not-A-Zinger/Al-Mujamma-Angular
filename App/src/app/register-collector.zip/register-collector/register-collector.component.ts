import { Component } from '@angular/core';

@Component({
  selector: 'app-register-collector',
  imports: [],
  templateUrl: './register-collector.component.html',
  styleUrl: './register-collector.component.css',
})
export class RegisterCollectorComponent {
  test() {
    alert('thisIsATest!');
  }
}
